// Firebase
const firebaseConfig = {
  apiKey: "ТВОЙ_API_KEY",
  authDomain: "ТВОЙ_ФАЙРБЕЙЗ.firebaseapp.com",
  projectId: "ТВОЙ_ФАЙРБЕЙЗ",
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

let currentUser = null;
auth.onAuthStateChanged(u => {
  currentUser = u;
  document.getElementById('login').style.display = u ? 'none' : 'inline-block';
  document.getElementById('logout').style.display = u ? 'inline-block' : 'none';
});

document.getElementById('login').onclick = () => auth.signInWithPopup(new firebase.auth.GoogleAuthProvider());
document.getElementById('logout').onclick = () => auth.signOut().then(() => location.reload());

const chatEl = document.getElementById('chat');
const inputEl = document.getElementById('input');
const fileInput = document.getElementById('fileInput');

document.getElementById('attachFile').onclick = () => fileInput.click();
fileInput.onchange = () => uploadFile(fileInput.files[0]);

document.getElementById('snap').onclick = () => takeSnapshot();

async function uploadFile(file) {
  const fd = new FormData();
  fd.append('file', file);
  const res = await fetch('/upload', {
    method: 'POST',
    body: fd,
    headers: { 'Authorization': currentUser ? 'Bearer ' + await currentUser.getIdToken() : '' }
  });
  const j = await res.json();
  addMessage('user', `📎 ${file.name}`);
}

function addMessage(cls, text) {
  const el = document.createElement('div');
  el.className = `message ${cls}`;
  el.innerText = text;
  chatEl.appendChild(el);
  chatEl.scrollTop = chatEl.scrollHeight;
}

document.getElementById('send').onclick = () => sendPrompt();
document.getElementById('clearChat').onclick = () => { chatEl.innerHTML = ''; };
document.getElementById('clearMemory').onclick = async () => {
  await fetch('/clear', {method:'POST', headers: {'Authorization': currentUser ? 'Bearer ' + await currentUser.getIdToken() : ''}});
  chatEl.innerHTML = '';
};

async function sendPrompt() {
  const prompt = inputEl.value.trim();
  if (!prompt) return;
  addMessage('user', prompt);
  inputEl.value = '';
  const res = await fetch('/generate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': currentUser ? 'Bearer ' + await currentUser.getIdToken() : ''
    },
    body: JSON.stringify({prompt})
  });
  if (!res.ok) { addMessage('ai', 'Ошибка ответа'); return; }
  const reader = res.body.getReader();
  let decoder = new TextDecoder(), done = false;
  addMessage('ai', '');
  const aiEl = chatEl.querySelector('.message.ai:last-child');
  while(!done) {
    const {value, done: d} = await reader.read();
    done = d;
    aiEl.innerText += decoder.decode(value || new Uint8Array, {stream: true});
    chatEl.scrollTop = chatEl.scrollHeight;
  }
}
